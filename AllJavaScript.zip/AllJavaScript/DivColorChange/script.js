function buttonColorChange(){
    var Newcolor = document.getElementById("myColor").value;
    console.log(Newcolor);
    document.getElementById("container").style.backgroundColor = Newcolor;
}


